# WebAssembly browser evaluation

Open benchmark/evidence/primary/REPORT.md for the pinned reference and portable interpreter results and benchmark/evidence/dispatch/REPORT.md for the arm64 automatic-dispatch comparison. The reports link measurement scope and outcome to exact binary hashes. The backend directory contains the corresponding architecture, compatibility and footprint evidence.

The benchmark package preserves the original JSC application attempt as an observation. Its distribution launcher accepts the measured JSC binary only in controls mode and serves only the two previously verified synchronous controls. The application fixtures can be run with the recorded Wasmi or Chrome artifacts; see benchmark/README.md. The original measurement archives remain unchanged in their source storage. This distribution contains reviewed copies, redacted local paths and fresh package checksums. No original application-attempt launcher is included.

Use SHA256SUMS from the extracted top-level directory to verify the package. Compiler and artifact fingerprints in the reports identify the measured builds; the distribution hash identifies this shareable copy. Read each directory's licensing notices before redistribution.
