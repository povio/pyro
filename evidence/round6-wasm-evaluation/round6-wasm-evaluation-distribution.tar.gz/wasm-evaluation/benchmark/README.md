# Browser Wasm measurements and control-only reruns

The primary report covers 91 process-level measurements and 28 compile/instantiate phase measurements. The dispatch report adds 40 fresh processes. Each report, chart and machine-readable raw record is in its own evidence directory. The results retain digests, binary fingerprints, status, timing, RSS, host load and the recorded JSC termination signal. Machine names were removed and original executable paths were reduced to artifact labels. original-evidence-hashes.json records source and distribution hashes. These are historical measurements; preparing this distribution ran no workload.

## Rerunning the controls and eligible examples

Use macOS arm64, Bun 1.4.4 and playwright-core 1.59.1. Inside harness, run bun install to install the pinned CDP client. Provide absolute executable paths to the separately supplied or independently built matching artifacts. The runner uses a fresh context, ephemeral loopback HTTP and CDP ports, and writes new files only under harness/reruns or WASM_BENCH_OUTPUT. The original reports and supplied raw records live elsewhere and are never used as write targets.

    bun run.mjs jsc "$PINNED_JSC" controls 1
    bun run.mjs wasmi "$WASMI_PORTABLE" smoke 1
    bun run.mjs wasmi "$WASMI_AUTO" smoke 1
    bun run.mjs chrome "$CHROME" smoke 1
    bun run.mjs wasmi "$WASMI_AUTO" timed 1
    bun run.mjs chrome "$CHROME" timed 1
    bun run.mjs wasmi "$WASMI_AUTO" phases 1
    bun run.mjs wasmi "$WASMI_AUTO" owner-progress 1
    bun run.mjs wasmi "$WASMI_AUTO" descriptor-observation 1

The pinned JSC entry serves its own control-only page script and exactly two SHA-256-checked inputs: the 8-byte empty module's synchronous lifecycle, and the 84-byte module's import descriptor inspection. The launcher checks the actual binary fingerprint before serving anything. The application entry accepts the two identified Wasmi artifacts and the recorded Chrome stable launcher. Both the primary report and the raw historical observation document the unavailable JSC application comparison.

Every application-mode timed invocation checks its full output against independent Python reference digests. Static inputs and modules are in fixtures, with the original C sources, compiler flags, checksums and LLVM 22.1.6 build script. The archived inputs avoid downloads for reruns. Optional fixture rebuilding uses WPT_CHECKOUT at commit a421f2fea5eb7f91e0db399e44b0fb0779ee1603 and LLVM_BIN pointing to LLVM 22.1.6. The scikit-image and WPT copyright notices are in licenses. The astronaut image is NASA public-domain material. The output reports describe the exact original engine order, dispersion and measurement settings; a single rerun is a new observation.

No experimental browser binaries or private project sources are included in this benchmark subtree. See the enclosing distribution for separately reviewed backend material.
