# Wasmi interpreter dispatch on arm64

The Wasmi source commits differ in a single dependency feature. The portable artifact selects portable-dispatch. The auto artifact selects auto-dispatch on the same Wasmi 2.0.2, JSC archive, arm64 target, wptiter profile and Rust embedding. Both artifacts meter fuel. Compare feature-change.patch and dispatch-proof.json for the build records.

| Workload | Portable µs/op | Auto µs/op | Portable/auto time (P10–P90) | Portable CV | Auto CV | Auto / previous Chrome time |
|---|---:|---:|---:|---:|---:|---:|
| image | 2,492.19 | 697.66 | 3.57× (3.56–3.58) | 0.4% | 0.6% | 14.4× |
| text | 2,235.94 | 620.31 | 3.61× (3.60–3.63) | 0.2% | 0.5% | 9.1× |
| audio | 3,467.97 | 721.88 | 4.81× (4.79–4.83) | 0.4% | 0.2% | 6.6× |
| text-host | 2,314.84 | 692.97 | 3.35× (3.33–3.35) | 0.3% | 0.3% | 7.8× |

The comparison used five adjacent matched pairs per workload at concurrency one. Within each round the workload order rotated, and the engine running first alternated across workloads and rounds. Every process loaded a fresh context, acquired the same immutable bytes and constructed a fresh instance. The warm metric is the median of nine 128-invocation batches, following three warmup batches. Each full input/output digest was checked on every timed invocation. Dispersion is across the five process medians. The Chrome column uses the earlier seven-process Chrome stable 157.0.8103.80 medians. Chrome was not remeasured during this follow-up.

| Workload | Portable cold ms | Auto cold ms | Portable RSS peak MiB | Auto RSS peak MiB |
|---|---:|---:|---:|---:|
| image | 2.90 | 1.10 | 65.2 | 65.7 |
| text | 2.60 | 1.10 | 65.1 | 65.6 |
| audio | 3.90 | 1.10 | 65.0 | 65.5 |
| text-host | 2.80 | 1.20 | 65.5 | 65.9 |

Cold time is one synchronous module construction, instantiation and first validated call. Each fresh-process RSS peak is sampled for the browser and descendants; it can include shared pages. CPU activity, baseline footprint and individual batch samples are available in the raw per-process JSON.

Both dispatch configurations passed the eight independent digest variants on all four applications. Each callback-index test executed 256 host callbacks per input. The import descriptor control checked a module whose declaration order was function/global/memory/table. Both candidates returned function/table/memory/global; neither received a timing sample for the invalid result. The async owner progress probe issued 64 distinct, normal compile requests on each fresh realm.

| Engine | Standalone bytes | SHA-256 | Async completed (3 realms) | Outstanding at each first timer |
|---|---:|---|---|---|
| portable | 135,628,864 | `5db291fc7ac8f30f9359b752c0144b84dff400220820d169479b5805b0eed731` | 64, 64, 64 | 64, 64, 64 |
| auto | 135,582,112 | `35b0c6f3643f65f511b6114e9982b33736863fbc5d6c2895a6594e845dbd5498` | 64, 64, 64 | 64, 64, 64 |

The independently compared upstream slice produced 31 auto and 31 portable pages, with 1845 and 1845 named occurrences and 991 and 991 passes respectively. Across those runs, 0 page statuses and 0 named outcomes changed.

The original 119 measurements, raw outputs and fixtures remained intact. This follow-up did not invoke the pinned JSC application path. Its earlier one-time SIGBUS outcome remains the boundary for that comparison.

## Interpretation

Automatic tail-call dispatch reduced elapsed warm execution time by 70.1–79.2% on the four matched kernels. Its standalone executable was 46,752 bytes smaller. The sampled median process-tree peak was 0.4–0.5 MiB higher, on roughly 65 MiB totals. The CPU-throughput tradeoff materially improved, while the resulting durations remained 6.6–14.4× the previously measured Chrome medians. The selected conformance cases and import-order gap were unaffected.

The 40 measurements had median host-wide CPU utilization 17.2% (range 13.9–37.3%) and one-minute load averages 3.7–22.7. The census and owned builds were paused during collection.
