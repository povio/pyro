# Independent Wasm application benchmark

Seven fresh processes per eligible engine and workload on Apple M1 Max, macOS 27.2.1 arm64. Browser concurrency was one. Each warm number is the median across seven process medians. Cold numbers are the median first lifecycle in each fresh process. All timed invocations passed their output oracle.

| Workload | Browser/engine | Warm µs/op | P10–P90 µs/op | CV | Cold ms | Sampled peak tree MiB | Median RSS growth MiB |
|---|---|---:|---:|---:|---:|---:|---:|
| empty | LP pinned JSC | 37.94 | 33.37–40.37 | 8.7% | 0.300 | 116.5 | 53.47 |
| empty | LP Wasmi 2.0.2 | 2.441 | 2.393–2.529 | 2.8% | 0.200 | 104.4 | 41.56 |
| empty | Chrome stable 157 | 5.664 | 5.420–5.977 | 4.4% | 0.100 | 1,203.8 | 50.23 |
| imports | LP pinned JSC | 0.665 | 0.651–0.670 | 1.5% | 0.400 | 124.8 | 61.81 |
| imports | LP Wasmi 2.0.2 | wrong import declaration order | — | — | — | — | — |
| imports | Chrome stable 157 | 0.562 | 0.553–0.576 | 1.9% | 0.200 | 1,180.5 | 220.1 |
| image | LP pinned JSC | JSC application path stopped at health gate | — | — | — | — | — |
| image | LP Wasmi 2.0.2 | 2,578.1 | 2,491.6–2,596.2 | 2.0% | 2.900 | 65.27 | 2.047 |
| image | Chrome stable 157 | 48.44 | 47.66–50.63 | 2.9% | 0.400 | 1,172.1 | 18.02 |
| text | LP pinned JSC | JSC application path stopped at health gate | — | — | — | — | — |
| text | LP Wasmi 2.0.2 | 2,312.5 | 2,233.3–2,330.5 | 2.1% | 2.700 | 65.08 | 1.922 |
| text | Chrome stable 157 | 67.97 | 62.19–75.31 | 8.3% | 0.500 | 1,177.2 | 24.62 |
| audio | LP pinned JSC | JSC application path stopped at health gate | — | — | — | — | — |
| audio | LP Wasmi 2.0.2 | 3,580.5 | 3,464.7–3,618.3 | 2.2% | 3.900 | 65.03 | 1.953 |
| audio | Chrome stable 157 | 110.2 | 108.8–111.9 | 1.6% | 0.500 | 1,178.4 | 258.3 |
| text-host | LP pinned JSC | JSC application path stopped at health gate | — | — | — | — | — |
| text-host | LP Wasmi 2.0.2 | 2,408.6 | 2,323.9–2,413.9 | 1.8% | 2.900 | 65.58 | 2.547 |
| text-host | Chrome stable 157 | 88.28 | 80.94–90.16 | 5.2% | 0.500 | 1,177.8 | 32.19 |

The empty control includes Module construction, Instance construction and an exports read. The imports control inspects metadata from a precompiled module during warm batches. App kernels reuse a compiled module and instance, and each call processes an entire input. Cold app totals include module construction, instantiation and the first call. Read-only fixture acquisition and browser startup happen before these timings. The raw JSON retains startup, cold phases, all batch timings, process-tree memory samples and host load.

| Workload | Paired Wasmi / Chrome warm duration | P10–P90 across 7 paired rounds |
|---|---:|---:|
| image | 52.00× | 50.91–53.73× |
| text | 32.85× | 30.34–37.35× |
| audio | 32.20× | 31.50–32.93× |
| text-host | 26.84× | 26.55–29.01× |

## Correctness and scope

The Wasmi candidate and Chrome each reproduced every seed digest on NASA-derived Sobel image processing, WPT documentation indexing, a 15-tap PCM FIR and indexing with 256 Wasm-to-JS callbacks per document. All four app modules use internal linear-memory loads and stores, confirmed by disassembly. The API subset exposes numeric functions, internal memory and function imports. Inputs were embedded before compilation. JS-to-Wasm memory upload, a live exported memory buffer, WASI, SIMD and threads were outside this benchmark.

The single isolated unmodified JSC image health check exited with SIGBUS before providing a digest. There was no retry or additional JSC application execution. App-to-app speed comparisons against that JSC binary are unavailable. The same immutable JSC binary completed its synchronous empty lifecycle and import metadata controls. Earlier pinned JSC async completion timeouts remain separate from timings.

The candidate returned all four imports but in function/table/memory/global order rather than the original function/global/memory/table declaration order. This control is excluded from Wasmi timings.

The separate 64-job async submission test observed a window timer before any compilation callbacks settled in each of three Wasmi processes and each of three Chrome processes. All 64 jobs subsequently completed in each trial. This establishes visible owner progress, not identical compilation throughput: the implementations and cache strategies differ.

The exact Wasmi candidate uses fuel-metered interpreted execution. Chrome uses its normal V8 compiler/tiering, and the reference LP uses its ordinary JSC backend. Their process models differ. Sampled aggregate RSS includes shared pages per process. Browser-start timing, timers and regular tasks can be influenced by other host work.

## Artifact identities

- LP pinned JSC, launcher/executable 131,207,696 bytes, SHA-256 `3f8ad1333c7faa773b0c729575375386d75e96b1314c39bfe3e26d87e8afc047`.
- LP Wasmi 2.0.2, launcher/executable 135,628,864 bytes, SHA-256 `5db291fc7ac8f30f9359b752c0144b84dff400220820d169479b5805b0eed731`.
- Chrome stable 157, launcher/executable 367,696 bytes, SHA-256 `304226ddaf697606b8bcbd2fbec20c6b6f6f56741ac492cb5deea7663bf10a74`.

The Chrome launcher is 367,696 bytes and loads a separate 531,683,616-byte framework. The standalone LP executables are directly comparable. Build/source provenance, fixture licences, commands and sampling details are in measurement-method.md. Results were produced only in the experiment cache.

## Supplemental compile and instantiate phases

Each phase below measures one JavaScript API constructor, in µs/op. The same-byte case repeats the original module. The unique-byte case appends a distinct four-byte payload in a valid custom section, prepared outside the timer, while keeping application instructions identical. Instantiation uses a precompiled module and regular imports. Each fresh process rotates phase order across three warm-up and nine timed batches of 32 objects per phase. The table reports the median across seven fresh processes, with P10–P90 in parentheses.

| Fixture | Warm phase | Wasmi µs/op | Chrome µs/op |
|---|---|---:|---:|
| text | compileSame | 18.75 (17.50–18.75) | 9.37 (9.37–9.38) |
| text | compileUnique | 18.75 (18.75–18.75) | 81.25 (81.25–85.63) |
| text | instantiate | 6.25 (6.25–6.25) | 9.38 (9.37–10.63) |
| text-host | compileSame | 18.75 (18.75–18.75) | 9.37 (9.37–9.38) |
| text-host | compileUnique | 18.75 (18.75–20.00) | 84.38 (83.12–87.50) |
| text-host | instantiate | 9.37 (6.25–9.38) | 12.50 (9.37–12.50) |

The primary stage comprised 91 successful fresh-process measurements. Median host-wide CPU busy time during a trial was 49.7% (range 19.4–64.7%), and one-minute load averages ranged from 8.3 to 17.4. Census launches and owned builds were paused during these timings. Background macOS media analysis and Spotlight remained active.
