(() => {
  const names = new Set(['empty', 'imports']);
  const clock = () => performance.now();
  let bytes, name, module;
  function check(ok, msg) { if (!ok) throw Error(msg); }
  function importsOf(m) {
    return WebAssembly.Module.imports(m).map(({module,name,kind}) => [module,name,kind]);
  }
  const expected = [['module','fn','function'],['module','global','global'],['module','memory','memory'],['module','table','table']];
  globalThis.bench = {
    async prepare(config) {
      name = config.name;
      check(names.has(name),'unsupported control');
      const response = await fetch('/modules/'+name+'.wasm');
      check(response.ok,'control unavailable');
      bytes = new Uint8Array(await response.arrayBuffer());
      const start=clock(); let last=start, min=Infinity;
      while(clock()-start<10) { const t=clock(); if(t>last)min=Math.min(min,t-last); last=t; }
      return {length:bytes.byteLength,timerResolutionMs:min};
    },
    cold() {
      const t0=clock(); module=new WebAssembly.Module(bytes); const t1=clock();
      if(name==='imports') {
        const desc=importsOf(module); const t2=clock();
        check(JSON.stringify(desc)===JSON.stringify(expected),'wrong descriptors');
        return {constructMs:t1-t0,descriptorMs:t2-t1,totalMs:t2-t0};
      }
      const instance=new WebAssembly.Instance(module,{}); const t2=clock();
      check(Object.keys(instance.exports).length===0,'unexpected exports'); const t3=clock();
      return {constructMs:t1-t0,instantiateMs:t2-t1,firstCallOrAccessMs:t3-t2,totalMs:t3-t0};
    },
    measure({batch,rounds,warmup}) {
      const samplesMs=[]; let tally=0;
      for(let r=0;r<rounds+warmup;r++) {
        const t=clock();
        for(let i=0;i<batch;i++) {
          if(name==='empty') {
            const inst=new WebAssembly.Instance(new WebAssembly.Module(bytes),{});
            check(Object.keys(inst.exports).length===0,'unexpected exports');
          } else {
            const desc=WebAssembly.Module.imports(module);
            check(desc.length===4&&desc[0].name==='fn'&&desc[3].kind==='table','wrong imports'); tally+=desc.length;
          }
        }
        if(r>=warmup)samplesMs.push(clock()-t);
      }
      return {samplesMs,batch,rounds,warmup,descriptorEntries:tally};
    }
  };
})();
