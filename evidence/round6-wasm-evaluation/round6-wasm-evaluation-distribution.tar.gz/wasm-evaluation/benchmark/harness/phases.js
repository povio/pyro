(() => {
  let bytes,name;
  const host={host:{batch:(k,n)=>((k*65537)+n)|0}};
  const clock=()=>performance.now();
  function assert(ok,msg){if(!ok)throw Error(msg);}
  function distinct(serial){
    const out=new Uint8Array(bytes.length+8);
    out.set(bytes);out.set([0,6,1,120,serial&255,(serial>>>8)&255,(serial>>>16)&255,(serial>>>24)&255],bytes.length);
    return out;
  }
  globalThis.bench={
    async prepare(config){
      name=config.name; const response=await fetch('/modules/'+name+'.wasm');assert(response.ok,'missing bytes');
      bytes=new Uint8Array(await response.arrayBuffer());
      return {length:bytes.length};
    },
    phases(){
      const compiled=new WebAssembly.Module(bytes), imports=name==='text-host'?host:{};
      const batches={compileSame:[],compileUnique:[],instantiate:[]};
      const types=Object.keys(batches),batchSize=32,rounds=9,warmup=3;
      let serial=0, last;
      for(let round=0;round<warmup+rounds;round++){
        for(let phase=0;phase<types.length;phase++){
          const type=types[(phase+round)%types.length];
          const inputs=type==='compileUnique'?Array.from({length:batchSize},()=>distinct(++serial)):null;
          const t=clock();
          if(type==='instantiate'){
            for(let i=0;i<batchSize;i++)last=new WebAssembly.Instance(compiled,imports);
          }else{
            for(let i=0;i<batchSize;i++)last=new WebAssembly.Module(inputs?inputs[i]:bytes);
          }
          const elapsed=clock()-t;
          if(type==='instantiate')assert(typeof last.exports.run==='function','missing expected export');
          else assert(WebAssembly.Module.exports(last).some(e=>e.name==='run' && e.kind==='function'),'missing descriptor');
          if(round>=warmup)batches[type].push(elapsed);
        }
      }
      return {batchSize,rounds,warmup,batches,uniqueModules:serial};
    }
  };
})();
