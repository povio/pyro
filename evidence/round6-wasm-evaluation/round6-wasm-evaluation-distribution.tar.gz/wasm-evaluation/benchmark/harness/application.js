(() => {
  function check(ok, message) { if (!ok) throw Error(message); }
  const clock = () => performance.now();
  const imports = {
    host: { batch(bucket, count) { callbacks++; return ((bucket * 65537) + count) | 0; } }
  };
  let callbacks = 0;
  let bytes, name, orig, module, instance, lastValue;
  const expectedImports = [
    ["module","fn","function"],["module","global","global"],["module","memory","memory"],["module","table","table"]
  ];
  function describe(module) {
    return WebAssembly.Module.imports(module).map(({module,name,kind})=>[module,name,kind]);
  }
  function invoke(variant) {
    // All timed invocations validate their full content digests independently.
    const value = instance.exports.run(variant) >>> 0;
    check(value === orig[variant], 'bad digest for ' + name + '/' + variant + ': ' + value + ' expected ' + orig[variant]);
    lastValue = value;
  }
  function repeat(n, f) { for (let i = 0; i < n; i++) f(i); }
  globalThis.bench = {
    async prepare(config) {
      ({name,expected:orig} = config);
      const response = await fetch('/modules/'+name+'.wasm');
      check(response.ok, 'fixture fetch failed');
      bytes = new Uint8Array(await response.arrayBuffer());
      const start = clock(); let last = start, min = Infinity;
      while(clock()-start < 10) {
        const t = clock();
        if (t>last) min=Math.min(min,t-last);
        last=t;
      }
      return {length:bytes.byteLength,timerResolutionMs:min};
    },
    cold() {
      const t0=clock();
      module=new WebAssembly.Module(bytes);
      const t1=clock();
      if (name === 'imports') {
        const descriptor=describe(module);
        const t2=clock();
        check(JSON.stringify(descriptor)===JSON.stringify(expectedImports), 'wrong imported declarations');
        return {constructMs:t1-t0,descriptorMs:t2-t1,totalMs:t2-t0};
      }
      instance=new WebAssembly.Instance(module,name==='text-host'?imports:{});
      const t2=clock();
      if (name==='empty') {
        const n=Object.keys(instance.exports).length;
        check(n===0,'empty exports');
      } else {
        invoke(0);
      }
      const t3=clock();
      return {constructMs:t1-t0,instantiateMs:t2-t1,firstCallOrAccessMs:t3-t2,totalMs:t3-t0};
    },
    declaredImports() { return describe(new WebAssembly.Module(bytes)); },
    smoke() {
      if(name==='empty' || name==='imports') { this.cold(); return {control:name,verified:true}; }
      const m = new WebAssembly.Module(bytes);
      instance = new WebAssembly.Instance(m,name==='text-host'?imports:{});
      const result=[];
      for (let i=0;i<8;i++) {invoke(i);result.push(lastValue);}
      if(name==='text-host')check(callbacks===8*256,'incorrect host callback coverage');
      return {result,callbacks};
    },
    async ownerProgress() {
      const count=64;
      let completed=0, firstTick;
      const t0=clock();
      const tick=new Promise(resolve=>setTimeout(()=>{
        firstTick={ms:clock()-t0,completed,outstanding:count-completed};
        resolve();
      },0));
      const promises=[];
      for(let i=0;i<count;i++) {
        // Tiny transparent custom sections give each valid module distinct bytes,
        // so identical-module caching does not answer the entire request.
        const b=new Uint8Array(bytes.length+5);
        b.set(bytes);b.set([0,3,1,120,i],bytes.length);
        promises.push(WebAssembly.compile(b).then(m=>{
          check(WebAssembly.Module.exports(m).some(e=>e.name==='run'),'missing async module export');
          completed++;
        }));
      }
      const enqueueMs=clock()-t0;
      await Promise.all(promises);
      const settledMs=clock()-t0;
      await tick;
      return {count,completed,enqueueMs,settledMs,firstTick};
    },
    measure({batch,rounds,warmup}) {
      const values=[];
      let sum=0;
      let tally=0;
      function block() {
        if (name==='empty') {
          repeat(batch,()=>{
            const mod=new WebAssembly.Module(bytes);
            const inst=new WebAssembly.Instance(mod);
            check(Object.keys(inst.exports).length===0,'empty API result');
          });
        } else if (name==='imports') {
          repeat(batch,()=>{
            const descriptor=WebAssembly.Module.imports(module);
            check(descriptor.length===4 && descriptor[0].name==='fn' && descriptor[3].kind==='table','wrong imports');
            tally += descriptor.length;
          });
        } else {
          const before=callbacks;
          repeat(batch,i=>{invoke(i&7);sum=(sum+lastValue)>>>0;});
          if (name==='text-host') check(callbacks-before===batch*256,'callback count mismatch');
        }
      }
      repeat(warmup,block);
      for(let i=0;i<rounds;i++) {
        const t=clock(); block(); values.push(clock()-t);
      }
      return {samplesMs:values,batch,rounds,warmup,checksum:sum,callbacks,descriptorEntries:tally};
    }
  };
})();
