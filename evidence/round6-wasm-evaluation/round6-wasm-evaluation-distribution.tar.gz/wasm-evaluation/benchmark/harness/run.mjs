import fs from 'node:fs';
import path from 'node:path';
import {fileURLToPath} from 'node:url';
import http from 'node:http';
import net from 'node:net';
import os from 'node:os';
import crypto from 'node:crypto';
import {spawn,execFileSync} from 'node:child_process';
import {createRequire} from 'node:module';
const D=path.dirname(fileURLToPath(import.meta.url));
const require=createRequire(import.meta.url);
const {chromium}=require('playwright-core');
const [engine,bin,mode='timed',trialArg='1']=process.argv.slice(2);
if (!['jsc','wasmi','chrome'].includes(engine) || !bin || !path.isAbsolute(bin))
  throw Error('run.mjs jsc|wasmi|chrome /absolute/path/to/browser MODE [trials]');
const trials=Number(trialArg), offset=0;
if (!Number.isInteger(trials) || trials<1 || trials>7) throw Error('trials must be 1 through 7');
const binarySha256=crypto.createHash('sha256').update(fs.readFileSync(bin)).digest('hex');
const jscSha256='3f8ad1333c7faa773b0c729575375386d75e96b1314c39bfe3e26d87e8afc047';
const wasmiHashes=new Set(['5db291fc7ac8f30f9359b752c0144b84dff400220820d169479b5805b0eed731','35b0c6f3643f65f511b6114e9982b33736863fbc5d6c2895a6594e845dbd5498']);
if (binarySha256===jscSha256 && engine!=='jsc') throw Error('pinned JSC requires the jsc controls-only entry');
if (engine==='jsc' && (binarySha256!==jscSha256 || mode!=='controls')) throw Error('jsc requires the pinned binary and controls mode');
if (engine==='wasmi' && !wasmiHashes.has(binarySha256)) throw Error('expected a recorded experimental Wasmi binary');
const chromeSha256='304226ddaf697606b8bcbd2fbec20c6b6f6f56741ac492cb5deea7663bf10a74';
if (engine==='chrome' && binarySha256!==chromeSha256) throw Error('expected the recorded Chrome stable launcher');
const apps=['image','text','audio','text-host'];
const selections={timed:apps,smoke:apps,phases:['text','text-host'],'owner-progress':['text'],'descriptor-observation':['imports']};
if (engine!=='jsc' && !Object.hasOwn(selections,mode)) throw Error('unknown application mode');
const names=engine==='jsc'?['empty','imports']:selections[mode];
const resultsDir=path.resolve(process.env.WASM_BENCH_OUTPUT || path.join(D,'reruns'));
fs.mkdirSync(resultsDir,{recursive:true});
const fixtures=path.join(D,'..','fixtures');
const expected=engine==='jsc'?{}:JSON.parse(fs.readFileSync(path.join(fixtures,'expected.json')));
const script=engine==='jsc'?'jsc-controls.js':mode==='phases'?'phases.js':'application.js';
const assets=new Map([['/',[Buffer.from('<!doctype html><meta charset=utf-8><script src="/bench.js"></script>'),'text/html']],
  ['/bench.js',[fs.readFileSync(path.join(D,script)),'text/javascript']]]);
const controlHashes={empty:'93a44bbb96c751218e4c00d479e4c14358122a389acca16205b1e4d0dc5f9476',imports:'536422db5875414da1e0c3365583e4fc383d83f9d2816536b51526119bb571db'};
for(const name of names) {
  const bytes=fs.readFileSync(path.join(fixtures,'modules',name+'.wasm'));
  if (engine==='jsc' && crypto.createHash('sha256').update(bytes).digest('hex')!==controlHashes[name])
    throw Error('pinned JSC control bytes differ from recorded input');
  assets.set('/modules/'+name+'.wasm',[bytes,'application/wasm']);
}
const server=http.createServer((req,res)=>{const entry=assets.get(req.url);if(!entry){res.writeHead(404);res.end();return;}res.writeHead(200,{'Content-Type':entry[1],'Cache-Control':'no-store'});res.end(entry[0]);});
await new Promise(resolve=>server.listen(0,'127.0.0.1',resolve));
const base='http://127.0.0.1:'+server.address().port;
const sleep=ms=>new Promise(resolve=>setTimeout(resolve,ms));
function treeSample(pid) {
  const byParent=new Map(),rows=new Map();
  for(const row of execFileSync('ps',['-axo','pid=,ppid=,rss='],{encoding:'utf8'}).trim().split('\n')) {
    const [p,pp,rss]=row.trim().split(/\s+/).map(Number);
    (byParent.get(pp)??byParent.set(pp,[]).get(pp)).push(p);rows.set(p,rss);
  }
  const todo=[pid];let total=0,count=0;
  while(todo.length){const p=todo.pop();if(rows.has(p)){total+=rows.get(p);count++;todo.push(...(byParent.get(p)??[]));}}
  return {treeKiB:total,processes:count};
}
const output={engine,binary:path.basename(bin),binaryBytes:fs.statSync(bin).size,binarySha256,mode,
  arch:os.arch(),osRelease:os.release(),cpus:os.cpus().length,started:new Date().toISOString(),concurrency:1,trials,results:[]};
function cpuTimes(){
  let busy=0,total=0;
  for(const {times} of os.cpus()){
    const b=times.user+times.nice+times.sys+times.irq;
    busy+=b;total+=b+times.idle;
  }
  return {busy,total};
}
const out=path.join(resultsDir,engine+'-'+mode+'-'+crypto.randomUUID()+'.json');
function save(){fs.writeFileSync(out+'.tmp',JSON.stringify(output,null,2));fs.renameSync(out+'.tmp',out);}
async function run(name,trial) {
  const s=net.createServer();await new Promise(resolve=>s.listen(0,'127.0.0.1',resolve));const port=s.address().port;await new Promise(resolve=>s.close(resolve));
  const profile=engine==='chrome'?fs.mkdtempSync(path.join(os.tmpdir(),'wasm-benchmark-')):null;
  const args=profile?['--headless','--disable-gpu','--disable-background-networking','--disable-component-update','--no-first-run','--no-default-browser-check','--remote-debugging-port='+port,'--user-data-dir='+profile,'about:blank']:
    ['serve','--host','127.0.0.1','--port',String(port),'--log-level','error'];
  const result={name,trial,start:new Date().toISOString(),load1:os.loadavg()[0]}, start=performance.now(),cpuBefore=cpuTimes();
  const proc=spawn(bin,args,{stdio:'ignore',detached:true});
  const exit=new Promise(resolve=>proc.once('exit',(code,signal)=>resolve({code,signal})));
  let browser,interval; let stopped=false;
  try {
    let version;
    for(let i=0;i<250;i++){
      if(proc.exitCode!=null||proc.signalCode)throw Error('browser exited before ready');
      try {const response=await fetch('http://127.0.0.1:'+port+'/json/version');if(response.ok){version=await response.json();break;}}catch{}
      await sleep(20);
    }
    if(!version)throw Error('browser failed to start');
    result.product=version.Browser;
    browser=await chromium.connectOverCDP('http://127.0.0.1:'+port,{timeout:10000});
    const ctx=await browser.newContext(),page=await ctx.newPage();
    page.setDefaultTimeout(120000);
    await page.goto(base,{waitUntil:'load',timeout:15000});
    result.startupToPageMs=performance.now()-start;
    result.prepare=await page.evaluate(config=>bench.prepare(config),{name,expected:expected[name]??[]});
    result.baseline=treeSample(proc.pid);
    let peak=result.baseline,maxProcesses=peak.processes,samples=0;
    function sample(){const now=treeSample(proc.pid);samples++;maxProcesses=Math.max(maxProcesses,now.processes);if(now.treeKiB>peak.treeKiB)peak=now;}
    interval=setInterval(sample,100);
    // Limit wall time for an unhealthy implementation; no automatic retries.
    const timeout=new Promise((_,reject)=>{const h=setTimeout(()=>reject(Error('benchmark wall timeout')),120000);h.unref();});
    const go=async ()=>{
      if(mode==='descriptor-observation'){result.declaredImports=await page.evaluate(()=>bench.declaredImports());return;}
      if(mode==='smoke'){result.smoke=await page.evaluate(()=>bench.smoke());return;}
      if(mode==='owner-progress'){result.ownerProgress=await page.evaluate(()=>bench.ownerProgress());return;}
      if(mode==='phases'){result.phases=await page.evaluate(()=>bench.phases());sample();return;}
      result.cold=await page.evaluate(()=>bench.cold());sample();
      const batch=name==='empty'?2048:name==='imports'?16384:128;
      result.warm=await page.evaluate(config=>bench.measure(config),{batch,rounds:9,warmup:3});
      sample();
    };
    await Promise.race([go(),timeout]);
    result.memory={peakKiB:peak.treeKiB,incrementKiB:peak.treeKiB-result.baseline.treeKiB,maxProcesses,samples};
    result.status='ok';
  } catch(e) {result.status='failed';result.error=String(e);result.signal=proc.signalCode;result.exitCode=proc.exitCode;}
  finally{
    clearInterval(interval);
    try{process.kill(-proc.pid,'SIGTERM');}catch{}
    const ended=await Promise.race([exit.then(()=>true),sleep(600).then(()=>false)]);
    if(!ended){try{process.kill(-proc.pid,'SIGKILL');}catch{};await Promise.race([exit,sleep(700)]);}
    if(profile)fs.rmSync(profile,{recursive:true,force:true,maxRetries:3,retryDelay:50});
  }
  const cpuAfter=cpuTimes(),ticks=cpuAfter.total-cpuBefore.total;
  result.hostCpuBusyPercent=ticks>0?100*(cpuAfter.busy-cpuBefore.busy)/ticks:null;
  return result;
}
try{
 const failed=new Set();
 for(let trial=0;trial<trials;trial++)for(let i=0;i<names.length;i++){
  const name=names[(i+trial+offset)%names.length];if(failed.has(name))continue;
  const r=await run(name,trial+offset);output.results.push(r);save();
  if(r.status!=='ok'){failed.add(name);console.error(engine,name,r.error);
    // An abnormal browser exit ends the engine run. Do not explore a fault with additional workloads.
    if(engine==='jsc' || r.signal || r.exitCode!==null && r.exitCode!==undefined){throw Error('browser terminated unexpectedly');}}
 }
 output.finished=new Date().toISOString();save();
}finally{server.close();}
