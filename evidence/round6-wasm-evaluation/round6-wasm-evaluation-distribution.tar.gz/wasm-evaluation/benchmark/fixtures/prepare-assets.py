"""Rebuild pinned inputs before compiling fixtures. The archived modules require no downloads."""
import hashlib,json,math,os,pathlib,struct,subprocess
d=pathlib.Path(__file__).parent; a=d/'assets'
w=pathlib.Path(os.environ['WPT_CHECKOUT'])
assert subprocess.check_output(['git','-C',str(w),'rev-parse','HEAD'],text=True).strip()=='a421f2fea5eb7f91e0db399e44b0fb0779ee1603'
if not (a/'astronaut.png').exists():
 subprocess.run(['curl','-fLsS','https://raw.githubusercontent.com/scikit-image/scikit-image/v0.24.0/skimage/data/astronaut.png','-o',str(a/'astronaut.png')],check=True)
subprocess.run(['magick',str(a/'astronaut.png'),'-resize','128x128!','-depth','8','RGB:'+str(a/'astronaut128.rgb')],check=True)
docs=json.loads((a/'docs-sources.json').read_text())
content=[]
for f in docs:
 b=(w/'docs/writing-tests'/f['file']).read_bytes();assert hashlib.sha256(b).hexdigest()==f['sha256'];content.append(b)
(a/'docs.txt').write_bytes(b'\n'.join(content)[:32768])
pcm=[round(12000*math.sin(2*math.pi*440*i/48000)+5000*math.sin(2*math.pi*1780*i/48000)) for i in range(16384)]
(a/'pcm16le.pcm').write_bytes(struct.pack('<16384h',*pcm))
for name,file,ty,x in [('image','astronaut128.rgb','unsigned char',None),('text','docs.txt','unsigned char',None),('audio','pcm16le.pcm','short',pcm)]:
 data=list((a/file).read_bytes()) if x is None else x
 (d/'src'/(name+'.inc')).write_text(f'static const {ty} input[] = {{\n'+',\n'.join(','.join(map(str,data[i:i+32])) for i in range(0,len(data),32))+'\n};\n')
