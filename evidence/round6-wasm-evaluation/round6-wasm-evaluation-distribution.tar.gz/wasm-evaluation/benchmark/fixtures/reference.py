import hashlib, json, os, pathlib, re, struct
p=pathlib.Path(__file__).parent;data=p/'assets'
def fnv(h,v):return ((h ^ v)*16777619)&0xffffffff
def digest(xs):
 h=2166136261
 for v in xs:h=fnv(h,v)
 return h
def image(v):
 rgb=(data/'astronaut128.rgb').read_bytes()
 g=[(77*r+150*h+29*b)>>8 for r,h,b in zip(rgb[::3],rgb[1::3],rgb[2::3])]
 vals=[]
 for y in range(1,127):
  for x in range(1,127):
   i=y*128+x
   dx=g[i-127]+2*g[i+1]+g[i+129]-g[i-129]-2*g[i-1]-g[i+127]
   dy=g[i+127]+2*g[i+128]+g[i+129]-g[i-129]-2*g[i-128]-g[i-127]
   vals.append(255 if abs(dx)+abs(dy)>=40+20*v else 0)
 return digest(vals)
def text(v):
 bins=[0]*256
 for word in re.findall(b'[a-z0-9]+',(data/'docs.txt').read_bytes().lower()):
  h=2166136261^v
  for ch in word:h=fnv(h,ch)
  bins[h&255]+=1
 return digest(k*65537+n for k,n in enumerate(bins))
def audio(v):
 signal=struct.unpack('<16384h',(data/'pcm16le.pcm').read_bytes())
 taps=[-3,-7,-4,10,33,60,83,92,83,60,33,10,-4,-7,-3]
 vals=[]
 for i in range(14,len(signal)):
  s=sum(t*signal[i-j] for j,t in enumerate(taps))*(8+v)
  fixed=(abs(s)//4096)*(1 if s>=0 else -1)
  vals.append(max(-32768,min(32767,fixed))&65535)
 return digest(vals)
expected={k:[f(i) for i in range(8)] for k,f in [('image',image),('text',text),('audio',audio)]}
expected['text-host']=expected['text']
(p/'expected.json').write_text(json.dumps(expected,indent=2)+'\n')
files=list((p/'modules').glob('*.wasm'))+list(data.glob('*'))
(p/'hashes.json').write_text(json.dumps({str(f.relative_to(p)):hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(files) if f.is_file()},indent=2)+'\n')
