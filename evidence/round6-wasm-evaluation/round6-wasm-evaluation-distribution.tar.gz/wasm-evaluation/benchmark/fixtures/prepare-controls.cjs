const fs = require('node:fs');
const vm = require('node:vm');
const path = require('node:path');
if (!process.env.WPT_CHECKOUT) throw Error('set WPT_CHECKOUT to the pinned WPT checkout');
const builder = fs.readFileSync(path.join(process.env.WPT_CHECKOUT,'wasm/jsapi/wasm-module-builder.js'),'utf8');
for (const [name, source] of [
  ['empty', 'new WasmModuleBuilder().toBuffer()'],
  ['imports', `(() => { const builder = new WasmModuleBuilder();
    builder.addImport("module", "fn", kSig_v_v);
    builder.addImportedGlobal("module", "global", kWasmI32);
    builder.addImportedMemory("module", "memory", 0, 128);
    builder.addImportedTable("module", "table", 0, 128);
    return builder.toBuffer(); })()`]
]) {
  const bytes = vm.runInNewContext(builder + '\n' + source);
  fs.writeFileSync(path.join(__dirname,'modules',name+'.wasm'),Buffer.from(bytes));
}
