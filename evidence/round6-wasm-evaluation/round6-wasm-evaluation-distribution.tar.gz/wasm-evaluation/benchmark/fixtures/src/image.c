#include "image.inc"
static unsigned char gray[128 * 128];
unsigned run(unsigned variant) {
    unsigned hash = 2166136261u;
    unsigned threshold = 40 + 20 * (variant & 7);
    for (unsigned i = 0; i < 128*128; ++i)
        gray[i] = (77u*input[3*i] + 150u*input[3*i+1] + 29u*input[3*i+2]) >> 8;
    for (unsigned y = 1; y < 127; ++y) {
        for (unsigned x = 1; x < 127; ++x) {
            const unsigned char *p = gray + y*128+x;
            int dx = p[-127] + 2*p[1] + p[129] - p[-129] - 2*p[-1] - p[127];
            int dy = p[127] + 2*p[128] + p[129] - p[-129] - 2*p[-128] - p[-127];
            unsigned magnitude = (dx < 0 ? -dx : dx) + (dy < 0 ? -dy : dy);
            hash = (hash ^ (magnitude >= threshold ? 255u : 0u)) * 16777619u;
        }
    }
    return hash;
}
