#include "audio.inc"
static const short taps[] = {-3, -7, -4, 10, 33, 60, 83, 92, 83, 60, 33, 10, -4, -7, -3};
static short filtered[16384];
unsigned run(unsigned variant) {
    unsigned gain = 8u + (variant & 7u);
    unsigned hash = 2166136261u;
    for (unsigned i = 14; i < 16384; ++i) {
        int sum = 0;
        for (unsigned j = 0; j < 15; ++j) sum += taps[j] * input[i-j];
        int scaled = (sum * (int)gain) / 4096;
        filtered[i] = scaled > 32767 ? 32767 : scaled < -32768 ? -32768 : (short)scaled;
    }
    for (unsigned i = 14; i < 16384; ++i)
        hash = (hash ^ (unsigned short)filtered[i]) * 16777619u;
    return hash;
}
