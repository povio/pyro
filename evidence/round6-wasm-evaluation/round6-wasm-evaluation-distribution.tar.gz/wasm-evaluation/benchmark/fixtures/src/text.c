#include "text.inc"
#ifdef HOST
__attribute__((import_module("host"), import_name("batch"))) extern unsigned batch(unsigned bucket, unsigned count);
#endif
static unsigned bins[256];
unsigned run(unsigned variant) {
    unsigned token = 2166136261u ^ (variant & 7);
    unsigned in_word = 0;
    for (unsigned k = 0; k < 256; ++k) bins[k] = 0;
    for (unsigned k = 0; k <= sizeof(input); ++k) {
        unsigned ch = k == sizeof(input) ? 0 : input[k];
        if (ch >= 'A' && ch <= 'Z') ch += 'a' - 'A';
        if ((ch >= 'a' && ch <= 'z') || (ch >= '0' && ch <= '9')) {
            token = (token ^ ch) * 16777619u;
            in_word = 1;
        } else if (in_word) {
            ++bins[token & 255u];
            token = 2166136261u ^ (variant & 7);
            in_word = 0;
        }
    }
    unsigned digest = 2166136261u;
    for (unsigned k = 0; k < 256; ++k) {
#ifdef HOST
        digest = (digest ^ batch(k, bins[k])) * 16777619u;
#else
        digest = (digest ^ (k * 65537u + bins[k])) * 16777619u;
#endif
    }
    return digest;
}
