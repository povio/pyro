#!/bin/sh
set -eu
cd "$(dirname "$0")"
toolsdir="${LLVM_BIN:?set LLVM_BIN to the LLVM 22.1.6 bin directory}"
for name in image text audio text-host; do
  source=${name%-host}; flags=
  if [ "$name" = text-host ]; then flags=-DHOST; fi
  "$toolsdir/clang" --target=wasm32-unknown-unknown -mcpu=mvp -O2 -fno-builtin -nostdlib $flags \
    -Wl,--no-entry,--strip-all,--export=run "src/$source.c" -o "modules/$name.wasm"
done
python3 internal-memory.py modules/image.wasm modules/text.wasm modules/audio.wasm modules/text-host.wasm
