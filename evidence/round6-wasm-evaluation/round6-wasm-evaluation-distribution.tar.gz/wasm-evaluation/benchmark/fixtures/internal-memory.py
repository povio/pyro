"""Remove LLVM's default memory export from these fixtures. The allocator and memory remain unchanged."""
import pathlib,sys
def take(buf,i):
 n=0
 for shift in range(0,35,7):
  b=buf[i]; i+=1; n|=(b&127)<<shift
  if b<128:return n,i
 raise ValueError('invalid uleb')
def size(n):
 b=bytearray()
 while n>=128:
  b.append((n&127)|128);n>>=7
 b.append(n);return b
for filename in sys.argv[1:]:
 p=pathlib.Path(filename);data=p.read_bytes();i=8;result=bytearray(data[:8])
 while i<len(data):
  tag=data[i];n,j=take(data,i+1);payload=data[j:j+n];i=j+n
  if tag==7:
   count,k=take(payload,0);entries=[]
   for _ in range(count):
    start=k;length,k=take(payload,k);name=payload[k:k+length];k+=length
    kind=payload[k];_,k=take(payload,k+1)
    if kind==2 and name==b'memory':continue
    entries.append(payload[start:k])
   assert count==2 and len(entries)==1 and b'run' in entries[0]
   payload=size(len(entries))+b''.join(entries)
  result.append(tag);result+=size(len(payload));result+=payload
 p.write_bytes(result)
