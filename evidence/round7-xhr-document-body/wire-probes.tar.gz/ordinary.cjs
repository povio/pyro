const fs=require('node:fs'),http=require('node:http'),net=require('node:net'),path=require('node:path'),cp=require('node:child_process'),os=require('node:os');
const w=__dirname,ref=path.join(path.dirname(w),'round6-reference-158/census'),pw=require(path.join(ref,'runner/node_modules/playwright-core'));
const [label]=process.argv.slice(2),wire=[];
const server=http.createServer(async(req,res)=>{
 if(!req.url.startsWith('/echo')){res.writeHead(200,{'Content-Type':'text/html'});res.end('<!doctype html><title>ordinary caller</title>');return;}
 const parts=[];for await(const chunk of req)parts.push(chunk);const data=Buffer.concat(parts);const row={id:new URL(req.url,'http://localhost').searchParams.get('id'),method:req.method,mime:req.headers['content-type']??null,hex:data.toString('hex')};wire.push(row);
 res.writeHead(200,{'Content-Type':'text/plain;charset=UTF-8'});res.end('received');
});
const listen=s=>new Promise(r=>s.listen(0,'127.0.0.1',()=>r(s.address().port)));
(async()=>{const port=await listen(server),sock=net.createServer(),cdp=await listen(sock);await new Promise(r=>sock.close(r));let proc,b;
 try{
 const bin=label==='base'?path.join(path.dirname(w),'round7-qa/bd247dd67/pyro'):label==='chrome158'?path.join(ref,'launch-158'):path.join(w,'pyro');
 const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'r7-xhr-fixture-'));
 proc=cp.spawn(bin,['serve','--host','127.0.0.1','--port',String(cdp),'--log-level','error','--load-resources','iframe'],{stdio:'ignore',env:{...process.env,WPT_CHROME_STATE_DIR:tmp,WPT_CHROME_REFERENCE_MODE:'wpt-stable'}});
 for(let i=0;i<120;i++){try{if((await fetch('http://127.0.0.1:'+cdp+'/json/version')).ok)break}catch{} await new Promise(r=>setTimeout(r,100))}
 b=await pw.chromium.connectOverCDP('http://127.0.0.1:'+cdp);const page=await b.newPage();await page.goto('http://127.0.0.1:'+port+'/page');
 const values=await page.evaluate(async()=>{
  const rows=[];const x=new XMLHttpRequest();
  async function send(id,body,header,method='POST'){await new Promise((resolve,reject)=>{x.open(method,'/echo?id='+id);if(header!==undefined)x.setRequestHeader('Content-Type',header);x.onload=resolve;x.onerror=reject;x.send(body)});rows.push([id,x.status])}
  const xml=new DOMParser().parseFromString('<m xmlns="urn:sample"><x>é雪</x></m>','application/xml');
  const doc=document.implementation.createHTMLDocument('Orders');doc.body.innerHTML='<br><p>item &amp; tax</p>';
  await send('xml-utf8',xml);await send('html-markup',doc);await send('xml-author',xml,'application/example+xml; CHARSET="latin1"; keep="a;b"; CharSet=ascii');
  await send('str-original','é','text/plain;  CHARSET="utf-8"; Keep=hello');await send('str-normalized','雪','text/plain; CHARSET=windows-1252; label="café"');
  await send('blob-original',new Blob(['snow'],{type:'application/example'}),'application/custom; charset=old');
  await send('buffer-original',new Uint8Array([0,65,255]),'application/custom; charset=old');
  await send('params-original',new URLSearchParams([['letter','é']]),'application/custom; charset=old');
  await send('get-ignores-doc',xml,undefined,'GET');await send('head-ignores-doc',xml,undefined,'HEAD');
  for(let i=0;i<72;i++)await send('sequential-'+i,'ok');
  return rows;
 });fs.writeFileSync(path.join(w,label+'-ordinary.json'),JSON.stringify({values,wire},null,1));
 }finally{if(b)await b.close();if(proc)proc.kill();server.close()}})().catch(e=>{console.error(e);process.exitCode=1});
