const http = require('node:http'), fs=require('node:fs'), cp=require('node:child_process'), net=require('node:net'), path=require('node:path');
const pw=require(path.resolve(__dirname,'../manifest-runner/bench/node_modules/playwright-core'));
const [label,bin]=process.argv.slice(2), requests=[];
const server=http.createServer((req,res)=>{
 const u=new URL(req.url,'http://localhost');
 if(u.pathname==='/echo'){requests.push({id:u.searchParams.get('id'),referrer:req.headers.referer??null}); const kind=u.searchParams.get('kind');if(kind==='script'){res.writeHead(200,{'Content-Type':'application/javascript'});return res.end('void 0')} if(kind==='style'){res.writeHead(200,{'Content-Type':'text/css'});return res.end('body{}')}if(kind==='image'){res.writeHead(200,{'Content-Type':'image/svg+xml'});return res.end('<svg xmlns="http://www.w3.org/2000/svg" width="1" height="1"/>')}res.writeHead(200,{'Content-Type':'text/html'});return res.end('<!doctype html><body>Echo</body>')}
 res.writeHead(200,{'Content-Type':'text/html','Referrer-Policy':'strict-origin-when-cross-origin'});res.end('<!doctype html><body>Document</body>');
});
const listen=s=>new Promise(r=>s.listen(0,'127.0.0.1',()=>r(s.address().port)));
(async()=>{
 const port=await listen(server),sock=net.createServer(),bp=await listen(sock);await new Promise(r=>sock.close(r));let proc,browser;
 try {
 if(bin==='chrome')browser=await pw.chromium.launch({executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:true});
 else{
 proc=cp.spawn(bin,['serve','--host','127.0.0.1','--port',String(bp),'--log-level','error','--load-resources','iframe','--load-resources','stylesheet'],{stdio:'ignore'});
 for(let i=0;i<100;i++){try{if((await fetch('http://127.0.0.1:'+bp+'/json/version')).ok)break}catch{}await new Promise(r=>setTimeout(r,100))}
 browser=await pw.chromium.connectOverCDP('http://127.0.0.1:'+bp)}
 const pages=[];
 for(const kind of ['blank','srcdoc']){
 const page=await browser.newPage(),origin='http://127.0.0.1:'+port,id=kind+'-inherited';
 await page.goto(origin+'/container/original');
 const result=await page.evaluate(async({kind,id})=>{let frame=document.createElement('iframe');
 const done=new Promise(r=>frame.onload=r);if(kind==='srcdoc')frame.srcdoc='<!doctype html><body></body>';
 document.body.append(frame);await done;let win=frame.contentWindow;const samples=[];
 for(const suffix of ['#one','#two']){
 win.history.replaceState({},'','about:'+kind+suffix);await new Promise(r=>setTimeout(r,0));samples.push({href:win.location.href,base:win.document.baseURI});
 }
 const req=new win.XMLHttpRequest();const loaded=new Promise(r=>{req.onload=r;req.onerror=r});req.open('GET','../echo?kind=xhr&id='+id);req.send();await loaded;
 return {samples,status:req.status};
 },{kind,id});pages.push({kind,...result,received:requests.some(x=>x.id===id)});await page.close();}
 fs.writeFileSync(path.join(__dirname,label+'.json'),JSON.stringify({pages,requests},null,2));
 }finally{if(browser)await browser.close();if(proc)proc.kill();server.close()}
})().catch(e=>{console.error(e);process.exit(1)});
