const http = require('node:http'), fs = require('node:fs'), cp = require('node:child_process'), os=require('node:os'), path = require('node:path'), net=require('node:net');
const base=path.join(os.homedir(),'Library/Caches/lightningpanda/round6-noncss-measure');
const pw=require(path.join(base,'manifest-runner/bench/node_modules/playwright-core'));
const harness=fs.readFileSync(path.join(base,'../wptci/wpt-full/resources/testharness.js'));
const unchanged=fs.readFileSync(path.join(base,'manifest-runner/bench/wpt/testharnessreport.js'),'utf8');
const [label,bin]=process.argv.slice(2);
const server=http.createServer((req,res)=>{
 const u=new URL(req.url,'http://localhost'),params=u.searchParams,mode=params.get('mode'),srcdoc=params.get('kind')==='srcdoc';
 function html(x){res.setHeader('Content-Type','text/html;charset=utf-8');res.end(x)}
 if(u.pathname==='/resources/testharness.js'){res.setHeader('Content-Type','text/javascript');res.end(harness);return}
 if(u.pathname==='/report.js'){res.setHeader('Content-Type','text/javascript');res.end(mode==='completion'?unchanged.replace('setup({ output: false });','setup({ output: false, message_events: ["completion"] });'):unchanged);return}
 if(u.pathname==='/echo'){res.setHeader('Content-Type','application/json');setTimeout(()=>res.end(JSON.stringify({referer:req.headers.referer??null})),11000);return}
 const head='<script src="/resources/testharness.js"></script><script src="/report.js?mode='+mode+'"></script>';
 const child='<!doctype html>'+head+'<script>window.addEventListener("message",async function onmessage(e){if(!e.data?.echo)return; const response=await fetch("/echo");const headers=await response.json();parent.postMessage({sourceContextUrl:location.href,headers},location.origin==="null"?"*":location.origin);},{once:true});</script>';
 if(u.pathname==='/child'){html(child);return}
 html('<!doctype html><meta name=timeout content=long>'+head+'<body><script>window.trace=[];window.samples=[];function shape(e){return {keys:Object.keys(e.data||{}),type:e.data?.type??null,harnessStatus:e.data?.status?.status??null,testCount:e.data?.tests?.length??null,header:e.data?.headers?.referer??null,src:e.data?.sourceContextUrl??null}};addEventListener("message",e=>trace.push(shape(e)));'+
 'for(let i=0;i<1;i++)promise_test(async t=>{const f=document.createElement("iframe");const loaded=new Promise(r=>f.onload=r);'+(srcdoc?'f.srcdoc='+JSON.stringify(child).replaceAll('<','\\u003c')+';':'f.src="/child?mode='+mode+'";')+
 'document.body.append(f);await loaded;const first=new Promise(resolve=>window.addEventListener("message",e=>resolve(shape(e)),{once:true}));const final=new Promise(resolve=>{function take(e){if(e.source===f.contentWindow&&e.data?.headers){window.removeEventListener("message",take);resolve(shape(e));}}window.addEventListener("message",take)});f.contentWindow.postMessage({echo:true},"*");const received=await first;const wanted=await final; samples.push({first:received,wanted});assert_true(!!wanted.header);},"header-"+i);</script>');
});
const listen=s=>new Promise(r=>s.listen(0,'127.0.0.1',()=>r(s.address().port)));
(async()=>{const p=await listen(server);const tmp=net.createServer();const bp=await listen(tmp);await new Promise(r=>tmp.close(r));let proc,browser;
 try {
 if(bin==='chrome'){browser=await pw.chromium.launch({executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:true})}else{
 proc=cp.spawn(bin,['serve','--host','127.0.0.1','--port',String(bp),'--log-level','error','--load-resources','stylesheet','--load-resources','iframe'],{stdio:'ignore'});
 for(let i=0;i<100;i++){try{if((await fetch('http://127.0.0.1:'+bp+'/json/version')).ok)break}catch{}await new Promise(r=>setTimeout(r,100))}
 browser=await pw.chromium.connectOverCDP('http://127.0.0.1:'+bp)}
 const out=[];
 await Promise.all(['iframe','srcdoc'].flatMap(kind=>['original','completion'].map(async(mode)=>{const i=0;const ctx=await browser.newContext(),page=await ctx.newPage();await page.goto('http://127.0.0.1:'+p+'/parent?mode='+mode+'&kind='+kind,{waitUntil:'commit'});let error=null;
 try{await page.waitForFunction(()=>window.samples?.length===1,null,{timeout:18000})}catch(e){error=e.message.split('\n')[0]}
 out.push({kind,mode,i,error,...(await page.evaluate(()=>({samples,trace})))});await ctx.close()})));
 fs.writeFileSync(path.join(__dirname,'slow-'+label+'.json'),JSON.stringify(out));console.log(label,out.map(x=>[x.kind,x.mode,x.samples.length,x.samples.filter(s=>!s.first.keys.includes('headers')).length,x.trace.filter(s=>s.type).length])); 
 }finally{if(browser)await browser.close();if(proc)proc.kill();server.close()}})().catch(e=>{console.error(e);process.exit(1)});
