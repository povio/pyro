const http=require('node:http'),cp=require('node:child_process'),fs=require('node:fs'),os=require('node:os'),path=require('node:path'),net=require('node:net');
const root=path.join(os.homedir(),'Library/Caches/lightningpanda/round6-noncss-measure');
const pw=require(path.join(root,'manifest-runner/bench/node_modules/playwright-core'));
const [label,bin]=process.argv.slice(2),requests=[];
const server=http.createServer((req,res)=>{
 const u=new URL(req.url,'http://localhost');
 if(u.pathname==='/headers'){requests.push({id:u.searchParams.get('id'),referrer:req.headers.referer??null});res.setHeader('Content-Type','text/plain');return res.end('ok')}
 let policy=u.searchParams.get('policy'); if(policy)res.setHeader('Referrer-Policy',policy);
 res.setHeader('Content-Type','text/html');res.end('<!doctype html><title>Ordinary same-origin document control</title><body>test');
});
const listen=s=>new Promise(r=>s.listen(0,'127.0.0.1',()=>r(s.address().port)));
(async()=>{const p=await listen(server),origin='http://127.0.0.1:'+p, sock=net.createServer(),bp=await listen(sock);await new Promise(r=>sock.close(r));let proc,b;
 try{if(bin==='chrome')b=await pw.chromium.launch({executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:true});else{
 proc=cp.spawn(bin,['serve','--host','127.0.0.1','--port',String(bp),'--log-level','error','--load-resources','stylesheet','--load-resources','iframe'],{stdio:'ignore'});
 for(let i=0;i<100;i++){try{if((await fetch('http://127.0.0.1:'+bp+'/json/version')).ok)break}catch{}await new Promise(r=>setTimeout(r,100))}
 b=await pw.chromium.connectOverCDP('http://127.0.0.1:'+bp)}
 const rows=[];
 for(const policy of ['strict-origin-when-cross-origin','origin','no-referrer'])for(const depth of [0,1,2]){const c=await b.newContext(); const pg=await c.newPage();const parent=origin+'/container?policy='+policy;
 await pg.goto(parent+'#fragment',{waitUntil:'load'});
 let frame=pg.mainFrame();
 for(let i=0;i<depth;i++){
 await frame.evaluate(async()=>{const f=document.createElement('iframe');f.srcdoc='<!doctype html><base href="/unrelated-base/"><title>Nested source</title>';const done=new Promise(r=>f.onload=r);document.body.append(f);await done});
 frame=frame.childFrames()[0];if(!frame)throw Error('missing nested frame')}
 for(const method of ['fetch','xhr','beacon']){
 const id=policy+'/'+depth+'/'+method; const url=origin+'/headers?id='+encodeURIComponent(id);
 await frame.evaluate(async({method,url})=>{if(method==='fetch'){await(await fetch(url)).text();return}if(method==='xhr'){await new Promise((r,j)=>{const x=new XMLHttpRequest();x.open('GET',url);x.onload=r;x.onerror=j;x.send()});return}if(!navigator.sendBeacon(url,'hello'))throw Error('beacon rejected')},{method,url});
 for(let i=0;i<50&&!requests.some(r=>r.id===id);i++)await new Promise(r=>setTimeout(r,10));
 const seen=requests.find(r=>r.id===id),expect=policy==='no-referrer'?null:policy==='origin'?origin+'/':parent;
 rows.push({id,observed:seen?.referrer??null,received:!!seen,expected:expect,pass:!!seen&&seen.referrer===expect})}
 await c.close()}
 fs.writeFileSync(path.join(__dirname,'headers-'+label+'.json'),JSON.stringify(rows,null,1));console.log(label,rows.filter(r=>r.pass).length+'/'+rows.length,rows.filter(r=>!r.pass).map(r=>r.id));
 }finally{if(b)await b.close();if(proc)proc.kill();server.close()}})().catch(e=>{console.error(e);process.exit(1)});
