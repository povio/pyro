const http = require('node:http'), fs=require('node:fs'), cp=require('node:child_process'), net=require('node:net'), path=require('node:path');
const pw=require(path.resolve(__dirname,'../manifest-runner/bench/node_modules/playwright-core'));
const [label,bin]=process.argv.slice(2), requests=[];
const execute=async({kind,id,size})=>{
 const path='/page/'+ 'a'.repeat(size-location.origin.length-6);
 history.pushState(null,'','/');history.replaceState({},'',path+'#fragment');
 const url='/echo?kind='+kind+'&id='+id;
 if(kind==='fetch')await(await fetch(url)).text();
 else if(kind==='xhr')await new Promise(resolve=>{const x=new XMLHttpRequest();x.open('GET',url);x.onload=resolve;x.send()});
 else {const tag={iframe:'iframe',script:'script',image:'img',style:'link'}[kind];
 const e=document.createElement(tag);const done=new Promise(r=>{e.onload=r;e.onerror=r});if(kind==='style'){e.rel='stylesheet';e.href=url}else{e.src=url}
 document.body.append(e);await Promise.race([done,new Promise(r=>setTimeout(r,1200))]);}
 return {doc:document.URL,length:location.href.split('#')[0].length};
 };
const server=http.createServer((req,res)=>{
 const u=new URL(req.url,'http://localhost');
 if(u.pathname==='/outer'){res.writeHead(200,{'Content-Type':'text/html'});res.end('<!doctype html><body><iframe src="/parser?'+u.searchParams.toString().replaceAll('&','&amp;')+'"></iframe>');return;}
 if(u.pathname==='/echo'){requests.push({id:u.searchParams.get('id'),referrer:req.headers.referer??null}); const kind=u.searchParams.get('kind');if(kind==='script'){res.writeHead(200,{'Content-Type':'application/javascript'});return res.end('void 0')} if(kind==='style'){res.writeHead(200,{'Content-Type':'text/css'});return res.end('body{}')}if(kind==='image'){res.writeHead(200,{'Content-Type':'image/svg+xml'});return res.end('<svg xmlns="http://www.w3.org/2000/svg" width="1" height="1"/>')}res.writeHead(200,{'Content-Type':'text/html'});return res.end('<!doctype html><body>Echo</body>')}
 res.writeHead(200,{'Content-Type':'text/html','Referrer-Policy':'strict-origin-when-cross-origin'});res.end('<!doctype html><body><script>(' + execute.toString()+')('+JSON.stringify({kind:u.searchParams.get('kind'),id:u.searchParams.get('id'),size:Number(u.searchParams.get('size'))})+').then(value=>window.result=value)</script></body>');
});
const listen=s=>new Promise(r=>s.listen(0,'127.0.0.1',()=>r(s.address().port)));
(async()=>{
 const port=await listen(server),sock=net.createServer(),bp=await listen(sock);await new Promise(r=>sock.close(r));let proc,browser;
 try {
 if(bin==='chrome')browser=await pw.chromium.launch({executablePath:'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome',headless:true});
 else{
 proc=cp.spawn(bin,['serve','--host','127.0.0.1','--port',String(bp),'--log-level','error','--load-resources','iframe','--load-resources','stylesheet'],{stdio:'ignore'});
 for(let i=0;i<100;i++){try{if((await fetch('http://127.0.0.1:'+bp+'/json/version')).ok)break}catch{}await new Promise(r=>setTimeout(r,100))}
 browser=await pw.chromium.connectOverCDP('http://127.0.0.1:'+bp)}
 const pages=[];
 for(const kind of ['fetch','xhr','iframe','script','image','style']) for(const size of [64,4095,4096,4097]){
 const page=await browser.newPage(),origin='http://127.0.0.1:'+port,id=kind+'-'+size;
 
 await page.goto(origin+'/outer?'+new URLSearchParams({kind,id,size}));
 await page.waitForFunction(()=>window.frames[0]?.result!==undefined);
 const r=await page.evaluate(()=>frames[0].result);
 const observed=requests.find(row=>row.id===id);
 const expected=size>4096?origin+'/':r.doc.split('#')[0];pages.push({kind,size,length:r.length,seen:!!observed,observed:observed?.referrer??null,expected,pass:observed?.referrer===expected});await page.close();
 }
 fs.writeFileSync(path.join(__dirname,label+'.json'),JSON.stringify({pages,requests},null,2));
 }finally{if(browser)await browser.close();if(proc)proc.kill();server.close()}
})().catch(e=>{console.error(e);process.exit(1)});
