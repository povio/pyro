const http=require('node:http'),fs=require('node:fs'),net=require('node:net'),path=require('node:path'),cp=require('node:child_process'),os=require('node:os');
const w=__dirname,ref=path.join(path.dirname(w),'round6-reference-158/census'),pw=require(path.join(ref,'runner/node_modules/playwright-core'));
const [label,explicit]=process.argv.slice(2);
const server=http.createServer((req,res)=>{res.setHeader('Content-Type','text/html');res.end('<!doctype html><body style="margin:0">');});
const listen=s=>new Promise(r=>s.listen(0,'127.0.0.1',()=>r(s.address().port)));
(async()=>{const port=await listen(server),sock=net.createServer(),cdp=await listen(sock);await new Promise(r=>sock.close(r));let proc,b;
 try{const bin=explicit||path.join(ref,'launch-158');
 const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'r7-svg-fixture-'));
 proc=cp.spawn(bin,['serve','--host','127.0.0.1','--port',String(cdp),'--log-level','error','--load-resources','stylesheet','--load-resources','iframe'],{stdio:'ignore',env:{...process.env,WPT_CHROME_STATE_DIR:tmp,WPT_CHROME_REFERENCE_MODE:'wpt-stable'}});
 for(let i=0;i<120;i++){try{if((await fetch('http://127.0.0.1:'+cdp+'/json/version')).ok)break}catch{}await new Promise(r=>setTimeout(r,100))}
 b=await pw.chromium.connectOverCDP('http://127.0.0.1:'+cdp);const page=await b.newPage();await page.goto('http://127.0.0.1:'+port+'/page');
 const values=await page.evaluate(()=>{
 const ns='http://www.w3.org/2000/svg',svg=document.createElementNS(ns,'svg'),rows=[];
 if(!svg.preserveAspectRatio)return {supported:false,rows};
 svg.setAttribute('width',300);svg.setAttribute('height',100);svg.setAttribute('viewBox','10 20 100 100');
 svg.setAttribute('preserveAspectRatio','none slice');const rect=document.createElementNS(ns,'rect');rect.setAttribute('x',10);rect.setAttribute('y',20);rect.setAttribute('width',10);rect.setAttribute('height',10);svg.append(rect);document.body.append(svg);
 const a=svg.preserveAspectRatio.baseVal,anim=svg.preserveAspectRatio.animVal;
 const expect=(name,actual,expected)=>rows.push({name,actual,expected,pass:JSON.stringify(actual)===JSON.stringify(expected)});
 expect('explicit none slice base components',[a.align,a.meetOrSlice],[1,2]);expect('explicit none slice animated components',[anim.align,anim.meetOrSlice],[1,2]);
 const r=rect.getBoundingClientRect(),v=svg.getBoundingClientRect();expect('viewport displacement and per-axis scale',[r.x-v.x,r.y-v.y,r.width,r.height],[0,0,30,10]);
 for(const property of ['align','meetOrSlice']){
  for(const [mode,obj,error] of [['base',a,'TypeError'],['animated',anim,'NoModificationAllowedError']]){
   const before=svg.getAttribute('preserveAspectRatio');let caught=null;
   try{obj[property]=0}catch(e){caught=e.name};expect(property+' invalid '+mode,caught,error);
   expect(property+' failed setting preserves attribute '+mode,svg.getAttribute('preserveAspectRatio'),before);
  }
  const sentinel=new Error('ordinary conversion failure');let caught=false,converted=0;
  try{anim[property]={valueOf(){converted++;throw sentinel}}}catch(e){caught=e===sentinel}
  expect(property+' readonly converts first',[caught,converted],[true,1]);
 }
 return {supported:true,rows};});
 fs.writeFileSync(path.join(w,label+'-spec-probe.json'),JSON.stringify(values,null,2));
 }finally{if(b)await b.close();if(proc)proc.kill();server.close()}})().catch(e=>{console.error(e);process.exitCode=1});
