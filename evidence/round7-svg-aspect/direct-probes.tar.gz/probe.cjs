const http=require('node:http'),fs=require('node:fs'),net=require('node:net'),path=require('node:path'),cp=require('node:child_process'),os=require('node:os');
const w=__dirname,ref=path.join(path.dirname(w),'round6-reference-158/census'),pw=require(path.join(ref,'runner/node_modules/playwright-core'));
const [label,explicit]=process.argv.slice(2);
const server=http.createServer((req,res)=>{res.setHeader('Content-Type','text/html');res.end('<!doctype html><body style="margin:0">');});
const listen=s=>new Promise(r=>s.listen(0,'127.0.0.1',()=>r(s.address().port)));
(async()=>{const port=await listen(server),sock=net.createServer(),cdp=await listen(sock);await new Promise(r=>sock.close(r));let proc,b;
 try{const bin=explicit||path.join(ref,'launch-158');
 const tmp=fs.mkdtempSync(path.join(os.tmpdir(),'r7-svg-fixture-'));
 proc=cp.spawn(bin,['serve','--host','127.0.0.1','--port',String(cdp),'--log-level','error','--load-resources','stylesheet','--load-resources','iframe'],{stdio:'ignore',env:{...process.env,WPT_CHROME_STATE_DIR:tmp,WPT_CHROME_REFERENCE_MODE:'wpt-stable'}});
 for(let i=0;i<120;i++){try{if((await fetch('http://127.0.0.1:'+cdp+'/json/version')).ok)break}catch{}await new Promise(r=>setTimeout(r,100))}
 b=await pw.chromium.connectOverCDP('http://127.0.0.1:'+cdp);const page=await b.newPage();await page.goto('http://127.0.0.1:'+port+'/page');
 const values=await page.evaluate(()=>{
 const ns='http://www.w3.org/2000/svg',make=t=>document.createElementNS(ns,t),rows=[];
 for(const tag of ['svg','symbol','view','image','marker','pattern','feImage']){
  const el=make(tag),wrapped=el.preserveAspectRatio;
  if(!wrapped){rows.push({tag,supported:false});continue}
  const a=wrapped.baseVal, anim=wrapped.animVal,snap=()=>[a.align,a.meetOrSlice,anim.align,anim.meetOrSlice,el.getAttribute('preserveAspectRatio')];
  const row={tag,brand:el.constructor.name,default:snap(),identity:[wrapped===el.preserveAspectRatio,a===wrapped.baseVal,anim===wrapped.animVal,a!==anim],parse:[],set:[]};
  for(const text of ['xMinYMin','xMaxYMax slice','\txMidYMax\nmeet ','none slice','defer xMaxYMin slice','bogus','xMinYMin bogus','xMinYMin meet extra','']){el.setAttribute('preserveAspectRatio',text);row.parse.push([text,...snap()])}
  el.removeAttribute('preserveAspectRatio');row.removed=snap();
  for(const [part,val] of [['align',4],['meetOrSlice',2],['align',1],['align',6],['meetOrSlice',1],['align',0],['align',11],['meetOrSlice',0],['meetOrSlice',3],['align',65540]]){let error=null;try{a[part]=val}catch(e){error=e.name}row.set.push([part,val,error,...snap()])}
  for(const part of ['align','meetOrSlice'])try{anim[part]=1;row['readonly'+part]=false}catch(e){row['readonly'+part]=e.name}
  rows.push(row);
 }
 const svg=make('svg'),rect=make('rect');svg.setAttribute('width','300');svg.setAttribute('height','100');svg.setAttribute('viewBox','0 0 100 100');rect.setAttribute('width','10');rect.setAttribute('height','10');svg.append(rect);document.body.append(svg);
 const box=()=>{const r=rect.getBoundingClientRect(),s=svg.getBoundingClientRect();return [r.x-s.x,r.y-s.y,r.width,r.height]};
 const geometry=[box()];if(svg.preserveAspectRatio){svg.preserveAspectRatio.baseVal.align=4;geometry.push(box());svg.preserveAspectRatio.baseVal.meetOrSlice=2;geometry.push(box());svg.preserveAspectRatio.baseVal.align=1;geometry.push(box())}
 return {rows,geometry,negative:make('rect').preserveAspectRatio===undefined};});
 fs.writeFileSync(path.join(w,label+'-probe.json'),JSON.stringify(values,null,2));
 }finally{if(b)await b.close();if(proc)proc.kill();server.close()}})().catch(e=>{console.error(e);process.exitCode=1});
