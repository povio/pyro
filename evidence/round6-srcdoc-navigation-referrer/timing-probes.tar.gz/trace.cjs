const http=require('node:http'),fs=require('node:fs'),net=require('node:net'),path=require('node:path'),os=require('node:os'),cp=require('node:child_process');
const d=path.resolve(__dirname,'..'),cache=path.dirname(d),ref=path.join(cache,'round6-reference-158/census'),pw=require(path.join(ref,'runner/node_modules/playwright-core'));
const [label,mode='rapid']=process.argv.slice(2),serverRows=[];
const vendor=fs.readFileSync(path.join(cache,'wptci/wpt-full/resources/testharness.js')),report=fs.readFileSync(path.join(ref,'runner/bench/wpt/testharnessreport.js'));
function scopeCode(){
 const id=window.name;top.register(window,id);top.note(id,'scope-script');
 addEventListener('message',function accept(e){
  if(e.data?.kind!=='go')return;
  removeEventListener('message',accept);const q=e.data;top.note(id,'go-received',{sourceOK:e.source===parent});
  const inner=document.createElement('iframe');inner.name=id+'-echo';inner.src=q.url;document.body.append(inner);
  top.register(inner.contentWindow,inner.name);top.note(id,'inner-append');
  const receiver=ev=>{
   const v=ev.data;
   if(v?.kind==='echo'&&v.id===id){top.note(id,'inner-received',{sourceOK:ev.source===inner.contentWindow,referrer:v.referrer});parent.postMessage({...v,kind:'result'},location.origin==='null'?'*':location.origin);removeEventListener('message',receiver);}
  };addEventListener('message',receiver);
 });
}
function outerCode(){
 window.events=[];window.samples=[];const sources=new Map();let expectedId=null,first=null;
 window.register=(win,id)=>sources.set(win,id);
 window.note=(id,stage,details={})=>events.push({at:Date.now(),id,stage,...details});
 addEventListener('message',e=>{
  const b=e.data,src=sources.get(e.source)??'unknown';
  const kind=b?.kind??b?.type??'other';
  if(kind==='result'||kind==='complete')note(expectedId,'top-message',{kind,src,sendId:b?.id??null,status:b?.status?.status??null,referrer:b?.referrer??null});
 });
 window.run=async({seed,layout,delay,rounds,harness,redirect})=>{
 for(let i=0;i<rounds;i++){
  const id=seed+'-'+i;expectedId=id;
  const f=document.createElement('iframe');f.name=id;
  const ready=new Promise(r=>f.onload=r);
  const scope='/scope?id='+id+'&h='+Number(harness);
  if(layout==='srcdoc')f.srcdoc=await(await fetch(scope)).text();else f.src=scope;
  document.body.append(f);register(f.contentWindow,id);await ready;note(id,'scope-load');let first=null,actual=null;
  const sample=await new Promise(resolve=>{
   const wanted=e=>{
    const v=e.data,src=sources.get(e.source)??'unknown';const captured={kind:v?.kind??v?.type??'other',src,sendId:v?.id??null,ts:Date.now(),status:v?.status?.status??null};
    first??=captured;
    if(v?.kind==='result'&&v.id===id){
      actual={...captured,sourceOK:e.source===f.contentWindow,referrer:v.referrer,serverReferrer:v.serverReferrer};
      removeEventListener('message',wanted);clearTimeout(timer);resolve({id,first,actual});
    }
   };addEventListener('message',wanted);const timer=setTimeout(()=>{removeEventListener('message',wanted);resolve({id,first,actual,timeout:true})},15000);
   f.contentWindow.postMessage({kind:'go',url:(redirect?'/redirect':'/echo')+'?id='+id+'&delay='+delay},'*');note(id,'go-sent');
  });samples.push(sample);if(sample.timeout)break;
 }
 return {samples,events};
 };
}
const server=http.createServer((req,res)=>{
 const u=new URL(req.url,'http://localhost');const id=u.searchParams.get('id');
 const send=(type,body)=>{res.setHeader('Content-Type',type);res.setHeader('Cache-Control','no-store');res.end(body)};
 if(u.pathname==='/resources/testharness.js')return send('application/javascript',vendor);
 if(u.pathname==='/resources/testharnessreport.js')return send('application/javascript',report);
 if(u.pathname==='/scope')return send('text/html','<!doctype html><body>'+(u.searchParams.get('h')==='1'?'<script src="/resources/testharness.js"></script><script src="/resources/testharnessreport.js"></script>':'')+'<script>('+scopeCode.toString()+')()</script>');
 if(u.pathname==='/redirect'){serverRows.push({id,at:Date.now(),stage:'redirect',referrer:req.headers.referer??null});res.writeHead(302,{Location:'/echo'+u.search});return res.end()}
 if(u.pathname==='/echo'){
 const header=req.headers.referer??null;serverRows.push({id,at:Date.now(),stage:'request',referrer:header});
 setTimeout(()=>{serverRows.push({id,at:Date.now(),stage:'response'});send('text/html','<!doctype html><body><script>const id='+JSON.stringify(id)+';top.note(id,"echo-script");parent.postMessage({kind:"echo",id,referrer:document.referrer,serverReferrer:'+JSON.stringify(header)+'},"*");</script>')},Number(u.searchParams.get('delay')));return;
 }
 send('text/html','<!doctype html><body><script>('+outerCode.toString()+')()</script>');
});
const listen=s=>new Promise(r=>s.listen(0,'127.0.0.1',()=>r(s.address().port)));
(async()=>{
 const port=await listen(server);let browser,proc;try{
 const sock=net.createServer(),cdp=await listen(sock);await new Promise(r=>sock.close(r));
 const engines={base:path.join(d,'merged-aa0268/batch/visible'),head:path.join(d,'merged-aa0268/accepted158/candidate'),chrome:path.join(ref,'launch-158'),candidate:path.join(__dirname,'pyro-headers')};
 const state=fs.mkdtempSync(path.join(os.tmpdir(),'referrer-trace-'));
 proc=cp.spawn(engines[label],['serve','--host','127.0.0.1','--port',String(cdp),'--log-level','error','--load-resources','stylesheet','--load-resources','iframe'],{stdio:'ignore',env:{...process.env,WPT_CHROME_STATE_DIR:state,WPT_CHROME_REFERENCE_MODE:'wpt-stable'}});
 for(let i=0;i<100;i++){try{if((await fetch('http://127.0.0.1:'+cdp+'/json/version')).ok)break}catch{}await new Promise(r=>setTimeout(r,100))}
 browser=await pw.chromium.connectOverCDP('http://127.0.0.1:'+cdp);
 const tasks=[];for(const layout of ['src','srcdoc']) for(const redirect of [true,false]){
  if(mode==='rapid')for(const harness of [true,false])tasks.push({layout,redirect,harness,delay:0,rounds:12});
  else for(const delay of [7000,11000])tasks.push({layout,redirect,harness:true,delay,rounds:1});
 }
 const records=[];for(let i=0;i<tasks.length;i+=4)await Promise.all(tasks.slice(i,i+4).map(async(task,k)=>{
   const ctx=await browser.newContext();try{const page=await ctx.newPage();const seed=label+'-'+mode+'-'+(i+k);const top='http://127.0.0.1:'+port+'/parent?seed='+seed;await page.goto(top);
   const result=await page.evaluate(args=>window.run(args),{...task,seed});records.push({seed,top,task,...result});}finally{await ctx.close()}
 }));
 fs.writeFileSync(path.join(__dirname,label+'-'+mode+'.json'),JSON.stringify({records,serverRows}));
 }finally{if(browser)await browser.close();if(proc)proc.kill();server.close()}
})().catch(e=>{console.error(e);process.exit(1)});
