import gzip, json, re, statistics
from collections import Counter
from pathlib import Path
import verify

root = Path(__file__).resolve().parent
prior = root.parent / 'integrated-6e0a8f84'
frozen = root.parent / 'frozen-evidence'
if (root/'refs').exists():
    prior, frozen = root/'refs/parent', root/'refs/frozen'
load = verify.load
def save(name, data):
    (root/name).write_bytes(gzip.compress(json.dumps(data, sort_keys=True, separators=(',',':')).encode(),mtime=0))
def metrics(rows):
    return dict(verify.stats(rows), status={(url,name,outcome) for url,(_,_,tests) in rows.items() for name,outcome in tests},pageState={(url,state,harness) for url,(state,harness,_) in rows.items()})
def strict(row):
    state,harness,tests = row
    return state=='complete' and harness==0 and bool(tests) and all(status=='Pass' for _,status in tests)
def named(rows):
    return {(url,name):status for url,(_,_,tests) in rows.items() for name,status in tests}
def focus_raw(label):
    return {row['url']:[row['status'],row['harnessStatus'],[[t['name'],t['status']] for t in row['subtests']]] for row in load(root/'focus'/f'{label}.json.gz')['results']}
report={}; resources={}; measured=load(root/'measurement.json'); snapshots=(root/'host.log').read_text().splitlines()
for cohort in ('main','supplement'):
    stems=[f'{index:02}' for index in range(24)] if cohort=='main' else [cohort]
    urls=load(frozen/f'{cohort}.json'); files=[root/f'raw-{stem}.json' for stem in stems]
    rows=verify.collect(files,set(urls),cohort=='supplement'); save(f'outcomes-{cohort}.json.gz',rows)
    refs={'parent':load(prior/f'outcomes-{cohort}.json.gz'),**{label:load(frozen/f'outcomes-{label}-{cohort}.json.gz') for label in ['frozen','chrome']}}
    for stem,file in zip(stems,files):
        raw=load(file); manifest=load(root/(f'urls-{stem}.json' if cohort=='main' else 'supplement.json')); assert Counter(manifest)==Counter(raw['plan']); assert raw['jobs']==2 and raw['mode']=='full' and raw['dirs']==['css'] and not raw['reuseContext']
        log=(root/f'run-{stem}.log').read_text(); resources[stem]={**{key:raw[key] for key in ['wallMs','browserCpuS','runnerCpuS','serverCpuS','restarts','watchdogKills']},**{key:float(re.search(r'^'+key+r' ([\d.]+)',log,re.M)[1]) for key in ('real','user','sys')},'httpPort':int(re.search(r'web-platform.test:(\d+)',log)[1]),'pages':len(manifest)}
    sets=metrics(rows); report[cohort]={'counts':{k:len(v) for k,v in sets.items()}}
    for label,ref in refs.items():
        orig=metrics(ref); diff={k:{'candidateOnly':sorted(v-orig[k]),'referenceOnly':sorted(orig[k]-v)} for k,v in sets.items()}; save(f'all-{cohort}-vs-{label}.json.gz',diff); report[cohort][label]={k:[len(a) for a in delta.values()] for k,delta in diff.items()}
        if label=='parent':
            changes={url:{'candidate':rows[url],'parent':ref[url]} for url in rows if rows[url]!=ref[url]}; save(f'ordered-{cohort}-vs-parent.json.gz',changes); report[cohort]['changedOrderedPages']=sorted(changes)
    if cohort=='main':
        focused={'parent':focus_raw('base'),'candidate':focus_raw('candidate'),'chrome':load(root/'focus/chrome.json')}; allrows=dict(candidate=rows,**refs); mismatches={label:[url for url,row in subset.items() if row!=allrows[label][url]] for label,subset in focused.items()}; names={k:named(v) for k,v in focused.items()}; gained={key for key,old in names['parent'].items() if old!='Pass' and names['candidate'][key]=='Pass'}; residual={key for key,old in names['parent'].items() if 'writing-mode' in key[0] and old=='Fail' and names['candidate'][key]=='Fail' and names['chrome'][key]=='Pass'}; assert len(gained)==42 and len(residual)==18 and len(names['parent'])==87; gainpages={url for url in focused['parent'] if strict(focused['candidate'][url]) and not strict(focused['parent'][url])}; delta=load(root/'all-main-vs-parent.json.gz'); cand=lambda metric:{tuple(v) if isinstance(v,list) else v for v in delta[metric]['candidateOnly']}; report['focus']={'gains':len(gained),'remaining':len(residual),'fullPageMismatches':mismatches,'expectedPages':len(gainpages),'otherGainedPages':sorted(cand('pages')-gainpages),'otherGainedPasses':sorted(cand('passes')-gained),'missingGains':sorted(gained-cand('passes'))}; save('focus-key-check.json.gz',{'gained':sorted(gained),'remaining':sorted(residual),'strictGainedPages':sorted(gainpages),'mismatches':mismatches})
cpu=[100-float(m[1]) for line in snapshots if (m:=re.search(r'([\d.]+)% idle',line))]; report['measurement']={'priorWallSeconds':int((prior/'primary-end').read_text())-int((prior/'primary-start').read_text()),'wallSeconds':measured['wall'],'shards':resources,'sums':{key:sum(row[key] for row in resources.values()) for key in ('real','user','sys','browserCpuS','runnerCpuS','serverCpuS','restarts','watchdogKills')},'hostSamples':len(cpu),'meanBusy':statistics.mean(cpu),'minBusy':min(cpu),'maxBusy':max(cpu),'ciWorkerSampleLines':sum('Runner.Worker' in line for line in snapshots),'ciListenerSampleLines':sum('Runner.Listener' in line for line in snapshots)}
focus_data=load(root/'focus-key-check.json.gz'); allfocus={label:(load(root/'outcomes-main.json.gz') if label=='candidate' else load(prior/'outcomes-main.json.gz') if label=='parent' else load(frozen/'outcomes-chrome-main.json.gz')) for label in ('candidate','parent','chrome')}; samples={label:named({url:allfocus[label][url] for url in focused[label]}) for label in allfocus}; crosscheck=[]
for url,name in sorted(names['parent']):
    key=(url,name); crosscheck.append(dict(url=url,name=name,expected={label:names[label][key] for label in names},actual={label:samples[label].get(key) for label in samples},kind='recovered' if key in gained else 'remaining' if key in residual else 'control'))
save('focus-crosscheck.json.gz',crosscheck)
report['focus']['actualMismatchNames']=[row for row in crosscheck if row['expected']!=row['actual']]
allow=[load(frozen/(label+'.json')) for label in ('main','supplement','withheld')]; assert [len(group) for group in allow]==[8082,41,39] and len(set(sum(allow,[])))==8162; assert sorted(sum([load(root/f'urls-{index:02}.json') for index in range(24)],[]))==sorted(allow[0]) and sorted(load(root/'supplement.json'))==sorted(allow[1]); assert all(not (24780<=row['httpPort']<=24789 or 24820<=row['httpPort']<=24829) for row in resources.values())
(root/'summary.json').write_text(json.dumps(report,indent=2)+'\n')
