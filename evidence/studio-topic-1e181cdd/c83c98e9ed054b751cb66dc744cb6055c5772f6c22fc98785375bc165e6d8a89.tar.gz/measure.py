import datetime, json, os, subprocess, time
from pathlib import Path
from threading import Event, Thread

root = Path.cwd()
comparison = root.parent / 'integrated-6e0a8f84'
stop = Event()
def monitor():
    with open('host.log', 'w', buffering=1) as log:
        while not stop.is_set():
            print(datetime.datetime.now(datetime.timezone.utc).isoformat(), file=log)
            subprocess.run("uptime; top -l 1 -n 0 | grep -E 'CPU usage|PhysMem'; ps -axo pid,ppid,pcpu,rss,comm | grep -Ei 'Runner[.](Worker|Listener)|/cargo$|/rustc$' | grep -v grep || true",shell=True,stdout=log)
            stop.wait(30)
worker = Thread(target=monitor,daemon=True)
worker.start()
start = time.time()
times = {}
try:
    labels = [f'{index:02}' for index in range(24)] + ['supplement']
    for offset in range(0,25,4):
        processes = []
        for label in labels[offset:offset+4]:
            if processes: time.sleep(2)
            supplement = label == 'supplement'
            command = ['/usr/bin/time','-lp','bun',str(comparison/'runner/bench/wpt/run.mjs'),'--wpt',os.environ['WPT_DIR'],'--kind','testharness','--dirs','css','--server','wptserve','--testdriver','--jobs','2','--tests',str(root/('supplement.json' if supplement else f'urls-{label}.json')),'--bin',f'candidate={root}/candidate-pyro','--out',str(root/f'raw-{label}.json')] + (['--worker-globals'] if supplement else [])
            with open(f'run-{label}.log','w') as log:
                times[label] = {'start':time.time(),'command':command}
                processes.append((label,subprocess.Popen(command,stdout=log,stderr=subprocess.STDOUT)))
        failures = [(label,process.wait()) for label,process in processes]
        if any(code for _,code in failures): raise RuntimeError(failures)
finally:
    end = time.time()
    stop.set(); worker.join()
    Path('measurement.json').write_text(json.dumps(dict(start=start,end=end,wall=end-start,runs=times),indent=2))
